<div class="row">
<div class="col-md-12">
<div class="copyright">
<?php
echo "<p>PHP Assignment &copy "; 
echo  date('Y');
echo " All Rights Reserved.</p>";
?>
</div>
</div>
</div>